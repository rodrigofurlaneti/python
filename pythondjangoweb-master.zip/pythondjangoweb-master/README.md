---
services: app-service\web, app-service
platforms: python
author: Rodrigo Luiz Madeira Furlaneti
---

# Exemplo de Python para o Serviço de Aplicativos do Azure - Django

Este é um aplicativo web Python criado na estrutura do [Django] (http://webdjango.azurewebsites.net) que você pode implantar
para o Serviço de aplicativos Azure.

Este código é gerado por [Python Tools for Visual Studio] (https://www.visualstudio.com/en-us/features/python-vs.aspx)
do modelo Django padrão. Os arquivos do Visual Studio foram removidos.

Para saber como implantar este aplicativo da Web inicial no App Service em alguns minutos, vá para
[Começar com aplicativos da Web no Azure App Service] (https://azure.microsoft.com/en-us/documentation/articles/app-service-web-get-started/).

## Licença

Consulte [LICENÇA] (LICENÇA).

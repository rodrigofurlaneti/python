"""
Package for django_get_started.
"""

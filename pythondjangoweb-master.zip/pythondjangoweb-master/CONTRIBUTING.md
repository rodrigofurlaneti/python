
Contribuindo para amostras Azure

Obrigado pelo seu interesse em contribuir com amostras de Azure!

Formas de contribuir

Você pode contribuir com amostras de Azure de várias maneiras diferentes:

Envie comentários sobre esta página de amostra, seja útil ou não.
Envie problemas por meio do rastreador de problemas no GitHub. Estamos monitorando ativamente os problemas e melhorando nossas amostras.
Se você deseja fazer alterações de código em amostras, ou contribuir com algo novo, siga o modelo de solicitação GitHub Forks / Pull: Forque o repo de amostra, faça a alteração e proponha-a de volta enviando uma solicitação de tração.

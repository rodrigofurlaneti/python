from django.contrib import admin
from books_cbv.models import Book

admin.site.register(Book)